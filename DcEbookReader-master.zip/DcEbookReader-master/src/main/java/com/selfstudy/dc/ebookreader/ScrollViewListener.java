package com.selfstudy.dc.ebookreader;

/**
 * Created by DC on 2015/8/30.
 */
public interface ScrollViewListener {
    void onScrollChanged(ObservableScrollView scrollView, int x, int y, int oldx, int oldy);
}
