package com.jksoft.utils;

/**
 * Created by Jackey on 2015/6/14.
 */
public class DBNames {
    public final static String DBNAME = "ebookmarks";
    public final int VERSION = 1;

    public final static class LOGTYPE {
        public final static String FILE = "file";
        public final static String DATABASE = "database";
        public final static String CONSOLE = "console";
    }
}
